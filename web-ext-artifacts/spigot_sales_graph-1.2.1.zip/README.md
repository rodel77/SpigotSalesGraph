# SpigotSellsViewer-ChromeExtension

Spigot Resource: https://www.spigotmc.org/resources/37425/

Download in ChromeStore: https://chrome.google.com/webstore/detail/spigot-sales-graph/ipcabmoaiebegllbfjbljlpcedjehiaj

Report issue: https://github.com/rodel77/SpigotSellsViewer-ChromeExtension/issues
